<?php if(Auth::guard('admin')->check()): ?>
  <?php 
  $route = "admin.logout"; 
  $name = Auth::guard('admin')->user()->name;
  ?>
<?php elseif(Auth::guard('company')->check()): ?>
  <?php 
  $route = "company.logout"; 
  $name = Auth::guard('company')->user()->name; 
  ?>
<?php elseif(Auth::guard('web')->check()): ?>
  <?php 
  $route = "user.logout"; 
  $name = Auth::guard('web')->user()->name; 
  ?>
<?php endif; ?>
<!-- Default Bootstrap navbar -->
<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #e3f2fd;">
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Job Portal</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="<?php echo e(Request::is('/') ? "active" : ""); ?>">
          <a class="nav-link" href="/">Home</a>
        </li>
        <li class="<?php echo e(Request::is('view') ? "active" : ""); ?>">
          <?php if(Auth::guard('admin')->check()): ?>
            <a class="nav-link" href="/view">Jobs_FrontEnd</a>
          <?php else: ?> 
            <a class="nav-link" href="/view">Jobs</a>
          <?php endif; ?>
        </li>
        <li class="<?php echo e(Request::is('contact') ? "active" : ""); ?>">
          <a class="nav-link" href="/contact">Contact</a>
        </li>
      </ul>
      <form class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="search" placeholder="Search for a job" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>

      <?php if(Auth::guard('admin')->check()): ?>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <?php echo e($name); ?> <span class="caret"></span>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="<?php echo e(route('jobs.index')); ?>">All Jobs</a>
            <a class="dropdown-item" href="<?php echo e(route('categories.index')); ?>">Categories</a>
            <a class="dropdown-item" href="<?php echo e(route('tags.index')); ?>">Tags</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="<?php echo e(route($route)); ?>"
                onclick="event.preventDefault();
                              document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

            </a>

          <form id="logout-form" action="<?php echo e(route($route)); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
          </form>
        </div>
      </li>

      <?php elseif(Auth::guard('company')->check()): ?>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <?php echo e($name); ?> <span class="caret"></span>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="<?php echo e(route('company.dashboard')); ?>">My Jobs</a>
            <a class="dropdown-item" href="#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="<?php echo e(route($route)); ?>"
                onclick="event.preventDefault();
                              document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

            </a>

          <form id="logout-form" action="<?php echo e(route($route)); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
          </form>
        </div>
      </li>

      <?php elseif(Auth::guard()->check()): ?>
      
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <?php echo e($name); ?> <span class="caret"></span>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="<?php echo e(route('home')); ?>">Dashboard</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="<?php echo e(route($route)); ?>"
                onclick="event.preventDefault();
                              document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

            </a>

          <form id="logout-form" action="<?php echo e(route($route)); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
          </form>
        </div>
      </li>
      <?php else: ?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Login
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="<?php echo e(route('login')); ?>">User</a>
          <a class="dropdown-item" href="<?php echo e(route('company.login')); ?>">Company</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Register
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="<?php echo e(route('register')); ?>">User</a>
          <a class="dropdown-item" href="<?php echo e(route('company.register')); ?>">Company</a>
        </div>
      </li>
      <?php endif; ?>
    </div>
</nav>
<?php /**PATH E:\xampp\htdocs\ddms\resources\views/partials/nav.blade.php ENDPATH**/ ?>