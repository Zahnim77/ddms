<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="content">

          <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          
        <br>
          <div class="container">
            <div class="row">
                <div class="col-md-12">
                  <div class="jumbotron">
                    <h1>Welcome to my Job Portal</h1>
                    <p class="lead">Thank you very much for visiting. This is a test website built with Laravel</p>
                    <p><a class="btn btn-success btn-lg" href="#" role="button">Popular Jobs</a></p>
                  </div>
                </div>
            </div>
            <div class="row">
              <div class="col-md-8">
                <div class="job-post">
                  <h3>Job Title</h3>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti exercitationem modi, quod ullam cumque pariatur. Sint iste quia aperiam, nisi minima corrupti error recusandae molestias, quae expedita nobis, hic beatae.</p>
                  <a href="#" class="btn btn-dark">Read more..</a>
                </div>
                <hr>
                <div class="job-post">
                  <h3>Job Title</h3>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti exercitationem modi, quod ullam cumque pariatur. Sint iste quia aperiam, nisi minima corrupti error recusandae molestias, quae expedita nobis, hic beatae.</p>
                  <a href="#" class="btn btn-dark">Read more..</a>
                </div>
                <hr>
                <div class="job-post">
                  <h3>Job Title</h3>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti exercitationem modi, quod ullam cumque pariatur. Sint iste quia aperiam, nisi minima corrupti error recusandae molestias, quae expedita nobis, hic beatae.</p>
                  <a href="#" class="btn btn-dark">Read more..</a>
                </div>
                <hr>
              </div>
              <div class="col-md-3 offset-md-1">
                <h2>Sidebar</h2>
              </div>
            </div>
            <div class="links">
            </div>

          </div>

        </div>
        
    </body>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH E:\xampp\htdocs\ddms\resources\views/welcome.blade.php ENDPATH**/ ?>