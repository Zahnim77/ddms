

<?php $__env->startSection('title', '| View JobPost'); ?>

<?php $__env->startSection('stylesheets'); ?>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<?php $__env->stopSection(); ?>
    
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h2>
                <?php echo e($job->job_title); ?>

                <small><span class="w3-tag w3-round w3-orange">
                    <?php echo e($job->company_name); ?> 
                </span></small>
            </h2>
            <hr>
        </div>
        <div class="col-md-8">
            <h4>Vacancy: 
                <span style="color:blue;"><?php echo e($job->vacancy); ?></span>
            </h4>
            <br>
            <h4>Salary</h4>
            <p class="lead"><?php echo e($job->salary); ?></p>
    
            <h4>Location</h4>
            <p class="lead"><?php echo e($job->location); ?></p>

            <h4>Category: 
                <span style="color:darkmagenta;"><?php echo e($job->category->name); ?></span>
            </h4>
            <br>
            <h4>TAGs: <span style="color:blue;"><?php echo e($job->tags->count()); ?></span>
                <?php $__currentLoopData = $job->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="w3-tag w3-round w3-teal">
                        <?php echo e($tag->name); ?>

                    </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h4>
        </div>
        <div class="col-md-4">
            <div class="card bg-light p-3">
                <dl class="dl-horizontal">
                    <dt>URL:</dt>
                    <dd style="color:blue;">
                        <a href="<?php echo e(route('view.single', $job->slug)); ?>">
                            <?php echo e(route('view.single', $job->slug)); ?>

                        </a>
                    </dd>
                </dl>
                <dl class="dl-horizontal">
                    <dt>Created at:</dt>
                    <dd style="color:green;"><?php echo e(date('jS M\'Y h:i A', strtotime($job->created_at))); ?></dd>
                </dl>
                <dl class="dl-horizontal">
                    <dt>Last Updated:</dt>
                    <dd style="color:green;"><?php echo e(date('jS M\'Y h:i A', strtotime($job->updated_at))); ?></dd>
                </dl>
                <hr>
                <div class="row">
                    <div class="col-sm-6">
                        <?php echo Html::linkRoute('company.edit', 'Edit', array('company'=>$job->company->id, 'job'=>$job->id), array('class' => 'btn btn-warning btn-block')); ?>

                    </div>
                    <div class="col-sm-6">
                        <?php echo Form::open(['route' => ['company.destroy', $job->id], 'method' => 'DELETE']); ?>

                        <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-block']); ?>

                        <?php echo Form::close(); ?>

                        <br>
                    </div>
                    <div class="col-sm-12">
                        <!-- Named 'company.index' method as 'company.dashboard' route -->
                        <?php echo Html::linkRoute('company.dashboard', '<< See All', [], ['class' => 'btn btn-light btn-block']); ?>

                    </div>
                </div>
            </div>
        </div>
        <h4>Job Details</h4>
        <p class="lead"><?php echo e($job->job_description); ?></p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ddms\resources\views/company/show.blade.php ENDPATH**/ ?>