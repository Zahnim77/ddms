<?php $name = Auth::guard('company')->user()->name; ?>
<?php $__env->startSection('title', "| $name"); ?>

<?php $__env->startSection('stylesheets'); ?>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                COMPANY Dashboard
                <small>
                    <span class="w3-tag w3-round w3-yellow">
                        <span class="w3-badge w3-red"><?php echo e($jobs->count()); ?></span> Jobs
                    </span>
                </small>
            </div>

            <div class="card-body">
                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <table class="table table-hover"> 
                    <thead class="thead-dark">
                        <tr>
                            <th>Job Title</th>
                            <th>Vacancy</th>
                            <th class="text-center">Job Details</th>
                            <th>Location</th>
                            <th>Posted</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
    
                    <tbody>
                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                        <tr>
                            
                            <th><?php echo e($job->job_title); ?></th>
                            <td style="color:blue;"><?php echo e($job->vacancy); ?></td>
    
                            <td>
                                <?php echo e(substr($job->job_description, 0, 250)); ?>

                                <br>
                                <?php echo e(strlen($job->job_description) > 250 ? "....." : ""); ?>

                            </td>
    
                            <td><?php echo e($job->location); ?></td>
                            <td style="color:green;"><?php echo e(date('jS M\'Y', strtotime($job->created_at))); ?></td>
                            
                            <td>
                                <a href="<?php echo e(route( 'jobs.show', $job->id )); ?>" class="btn btn-secondary btn-sm">View</a>
                                <div><br></div>
                                <a href="<?php echo e(route( 'jobs.edit', $job->id )); ?>" class="btn btn-warning btn-sm">Edit</a>
                            </td>
    
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ddms\resources\views/company.blade.php ENDPATH**/ ?>