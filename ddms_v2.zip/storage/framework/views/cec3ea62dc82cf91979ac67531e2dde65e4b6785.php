

<?php $__env->startSection('title', '| Create jobPost'); ?>

<?php $__env->startSection('stylesheets'); ?>
    <?php echo Html::style('css/parsley.css'); ?> 
    <?php echo Html::style('css/select2.min.css'); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Auth::guard('company')->check()): ?>
        <?php 
        $company_name = Auth::guard('company')->user()->name; 
        ?>
    <?php else: ?>
        <?php $company_name = ""; ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <h1>Create New Job Post</h1>
            <hr>
            <?php echo Form::open(['route' => 'company.store', 'data-parsley-validate' => '' ]); ?>


                <?php echo e(Form::label('company_name', 'Company Name:')); ?> 
                <?php echo e(Form::text('company_name', null, array('class' => 'form-control', 'required' => '', 'maxlength' => '255', 'placeholder' => $company_name))); ?> 
                <br>
                <?php echo e(Form::label('job_title', 'Job Title:')); ?> 
                <?php echo e(Form::text('job_title', null, array('class' => 'form-control', 'required' => '', 'maxlength' => '255'))); ?> 
                <br>
                <?php echo e(Form::label('vacancy', "Vacancy:")); ?>

                <?php echo e(Form::number('vacancy', null, array('class' => 'form-control', 'required' => ''))); ?>

                <br>
                <?php echo e(Form::label('slug', 'Slug URL:')); ?> 
                <?php echo e(Form::text('slug', null, array('class' => 'form-control', 'required' => '', 'minlength' => '5','maxlength' => '255'))); ?> 
                <br>
                <?php echo e(Form::label('category_id', 'JOB Category:')); ?> 
                <select name="category_id" id="category_id" class="form-control">
                    <option style="font-style:italic;color:orangered;" value="#" selected>Choose a Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br>
                <?php echo e(Form::label('job_description', "Job Details:")); ?>

                <?php echo e(Form::textarea('job_description', null, array('class' => 'form-control', 'required' => ''))); ?>

                <br>
                <?php echo e(Form::label('salary', "Salary Range:")); ?>

                <?php echo e(Form::text('salary', null, array('class' => 'form-control', 'required' => ''))); ?>

                <br>
                <?php echo e(Form::label('location', "Location:")); ?>

                <?php echo e(Form::text('location', null, array('class' => 'form-control', 'required' => ''))); ?>

                <br>
                <?php echo e(Form::label('tags', 'TAGs:')); ?> 
                <select name="tags[]" id="tags[]" class="form-control select2-multiple" multiple="multiple">
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br><br>
                <?php echo e(Form::submit('Create Job', array('class' => 'btn btn-success btn-lg btn-block'))); ?>

                
            <?php echo Form::close(); ?>

            <br>
        </div>
    </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo Html::script('js/parsley.min.js'); ?>


    <?php echo Html::script('js/select2.min.js'); ?>

    <script type="text/javascript">
        $(document).ready(function() {
            $('.select2-multiple').select2();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ddms\resources\views/company/create.blade.php ENDPATH**/ ?>