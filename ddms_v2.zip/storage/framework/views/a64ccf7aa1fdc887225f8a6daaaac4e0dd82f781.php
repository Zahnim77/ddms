

<?php $__env->startSection('title', '| Edit Job Post'); ?>

<?php $__env->startSection('stylesheets'); ?>
    <?php echo Html::style('css/parsley.css'); ?>  
    <?php echo Html::style('css/select2.min.css'); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">

        <?php echo Form::model($job, ['route' => ['jobs.update', $job->id], 'method' => 'PUT', 'data-parsley-validate' => '' ]); ?>

            
            <?php echo e(Form::label('company_name', 'Company Name:')); ?> 
            <?php echo e(Form::text('company_name', null , array('class' => 'form-control', 'style'=>'font-size:1.5rem', 'required' => '', 'maxlength' => '255'))); ?> 
            <br>
            <?php echo e(Form::label('job_title', 'Job Title:')); ?> 
            <?php echo e(Form::text('job_title', null, array('class' => 'form-control', 'style'=>'font-size:1.5rem', 'required' => '', 'maxlength' => '255'))); ?> 
            <br>
        </div>
        <div class="col-md-8">
            <?php echo e(Form::label('vacancy', "Vacancy:")); ?>

            <?php echo e(Form::number('vacancy', null, array('class' => 'form-control', 'required' => ''))); ?>

            <br>
            <?php echo e(Form::label('category_id', "JOB Category:")); ?>

            <?php echo e(Form::select('category_id', $categories, null, ['class'=>'form-control'])); ?>

            <br>
            <?php echo e(Form::label('salary', "Salary Range:")); ?>

            <?php echo e(Form::text('salary', null, array('class' => 'form-control', 'required' => ''))); ?>

            <br>
            <?php echo e(Form::label('location', "Location:")); ?>

            <?php echo e(Form::text('location', null, array('class' => 'form-control', 'required' => ''))); ?>

            <br>
        </div>
        <div class="col-md-4">
            <div class="well">
                <dl class="dl-horizontal">
                    <dt>Created at:</dt>
                    <dd style="color:green;"><?php echo e(date('jS M\'Y h:i A', strtotime($job->created_at))); ?></dd>
                </dl>
                <dl class="dl-horizontal">
                    <dt>Last Updated:</dt>
                    <dd style="color:green;"><?php echo e(date('jS M\'Y h:i A', strtotime($job->updated_at))); ?></dd>
                </dl>
                <hr>
                <div class="row">
                    <div class="col-sm-6">
                        <?php echo Html::linkRoute('jobs.show', 'Cancel', array($job->id), array('class' => 'btn btn-light btn-block')); ?>

                    </div>
                    <div class="col-sm-6">
                        <?php echo e(Form::submit('Update', ['class' => 'btn btn-success btn-block'])); ?>

                    </div>
                </div>
            </div>
            <br>
            <?php echo e(Form::label('tags', "TAGs:")); ?>

            <?php echo e(Form::select('tags[]', $tags, null, ['class' => 'form-control select2-multiple', 'multiple' => 'multiple'])); ?>

            <br><br>
            <?php echo e(Form::label('slug', 'Slug URL:')); ?> 
            <?php echo e(Form::text('slug', null, array('class' => 'form-control', 'required' => '', 'minlength' => '5', 'maxlength' => '255'))); ?> 
        </div>
        <div class="col-md-12">
            <?php echo e(Form::label('job_description', "Job Details:")); ?>

            <?php echo e(Form::textarea('job_description', null, array('class' => 'form-control', 'required' => ''))); ?>


        <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo Html::script('js/parsley.min.js'); ?>


    <?php echo Html::script('js/select2.min.js'); ?>

    <script type="text/javascript">
        $(document).ready(function() {
            $('.select2-multiple').select2();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ddms\resources\views/jobs/edit.blade.php ENDPATH**/ ?>