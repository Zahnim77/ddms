

<?php $__env->startSection('title', '| JOB Categories'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-7">
            <h1>Categories</h1>
            <hr>
            <h3>Total: <?php echo e($categories->total()); ?> </h3>
            <br>
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th>iD</th>
                        <th>Category Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php echo Form::model($category, ['route' => ['categories.update', $category->id], 'method' => 'PATCH', 'data-parsley-validate' => '' ]); ?>

                        <td><?php echo e($category->id); ?></td>
                        <td>
                            <?php echo e(Form::text('name', null, array('class' => 'form-control', 'required' => ''))); ?>

                        </td>
                        <td>
                            <?php echo e(Form::submit('Update', ['class' => 'btn btn-warning btn-sm'])); ?>

                        
                        <?php echo Form::close(); ?>    
                        
                        <?php echo Form::open(['route' => ['categories.destroy', $category->id], 'method' => 'DELETE', 'style'=>'display:inline; margin-left:8px']); ?>

                        <?php echo e(Form::submit('Delete', array('class' => 'btn btn-danger btn-sm'))); ?>

                        <?php echo Form::close(); ?>

                        </td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php echo $categories->links(); ?> <!-- pagination -->
        </div>

        <div class="col-md-4 offset-md-1">
            <br><br><br>
            <div class="card bg-light p-3">

            <?php echo Form::open(['route' => 'categories.store']); ?>

                <h5 class="card-title">Create New Category</h5>

                <?php echo e(Form::text('name', null, ['class'=>'form-control'])); ?>

                <br>
                <?php echo e(Form::submit('Submit', ['class'=>'btn btn-secondary'])); ?>

                
            <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ddms\resources\views/categories/index.blade.php ENDPATH**/ ?>