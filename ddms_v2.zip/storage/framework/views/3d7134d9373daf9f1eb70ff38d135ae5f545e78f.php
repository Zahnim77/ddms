<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>  
    <div class="container">
      <div class="row">
          <div class="col-md-12">
            <div class="jumbotron">
              <h1>Welcome to my Job Portal</h1>
              <p class="lead">Thank you very much for visiting. This is a test website built with Laravel</p>
              <h4>ADMIN Panel: 
                <span>
                  <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(route('admin.dashboard')); ?></a>
                </span>
              </h4>
              <p>
                <strong>Username: </strong>
                <span style="color:orange;">Minhaz</span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <strong>Password: </strong>
                <span style="color:orange;">password</span>
              </p>
            </div>
          </div>
      </div>
      <div class="row">
        <div class="col-md-8">

          <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="job-post">

            <h4><?php echo e($job->job_title); ?></h4>

            <h4>Vacancy: 
              <span style="color:blue;"><?php echo e($job->vacancy); ?></span>
              <span style="float:right; color:orange;">
                <?php echo e($job->location); ?>

              </span>
            </h4>

            <p>
              <?php echo e(substr($job->job_description, 0, 300)); ?>

              &nbsp;
              <?php echo e(strlen($job->job_description) > 250 ? "....." : ""); ?>

            </p>
            <a href="<?php echo e(url('view/'.$job->slug)); ?>" class="btn btn-dark">.. Read more</a>
          </div>
          <hr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </div>
        <div class="col-md-3 offset-md-1">
          <h2>Sidebar</h2>
        </div>
      </div>
      <div class="links">
      </div>

    </div>

  </div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ddms\resources\views/pages/welcome.blade.php ENDPATH**/ ?>