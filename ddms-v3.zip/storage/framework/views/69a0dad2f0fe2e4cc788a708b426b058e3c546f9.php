<div class="row">
    <div class="col-md-8 offset-md-2">
        <p><?php echo e($bodyMsg); ?></p>
        <br>
        The email is sent from <?php echo e($email); ?>

    </div>
</div><?php /**PATH E:\xampp\htdocs\ddms\resources\views/emails/contact.blade.php ENDPATH**/ ?>