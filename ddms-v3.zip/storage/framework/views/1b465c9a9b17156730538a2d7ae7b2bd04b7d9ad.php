
<?php 
    $jobTitle = htmlspecialchars($job->job_title); 
?>
<?php $__env->startSection('title', "| $jobTitle"); ?>

<?php $__env->startSection('stylesheets'); ?>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-md-12">
            <h2><?php echo e($job->job_title); ?></h2>
            <hr>
        </div>
        <div class="col-md-6">
            <h4>Vacancy: 
                <span style="color:blue;"><?php echo e($job->vacancy); ?></span>
            </h4>
            <h4>Salary</h4>
            <p class="lead"><?php echo e($job->salary); ?></p>
            <h4>Category: 
                <span style="color:darkmagenta;"><?php echo e($job->category->name); ?></span>
            </h4>
        </div>
        <div class="col-md-6">
            <h4>Location</h4>
            <p class="lead"><?php echo e($job->location); ?></p>

            <h4>Created at:</h4>
            <p class="lead"><?php echo e(date('jS M\'Y h:i A', strtotime($job->created_at))); ?></p>
        </div>
        <div class="col-md-12">
            <h4>TAGs: 
                <?php $__currentLoopData = $job->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="w3-tag w3-round w3-teal">
                        <?php echo e($tag->name); ?>

                    </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h4>
        </div>
        <div class="col-md-12">
            <br>
            <h4>Job Details</h4>
            <p class="lead"><?php echo e($job->job_description); ?></p>
            <br>
        </div>
        <div class="col-md-4 offset-md-4">
            <?php if(Auth::guard('web')->check()): ?>
                <?php $userID = Auth::guard('web')->user()->id; ?>
                <?php if(isset(Auth::guard('web')->user()->cv)): ?>
                <?php echo Html::linkRoute('application', 'Apply', array($job->slug, $userID), array('class' => 'btn btn-success btn-block btn-lg')); ?>

                <?php else: ?> 
                <?php echo e(Html::linkRoute('profile', 'Apply', [$userID], array('class' => 'btn btn-success btn-block btn-lg'))); ?>

                <?php endif; ?>
            <?php else: ?> 
            <?php echo e(Html::linkRoute('login', 'Apply', [], array('class' => 'btn btn-success btn-block btn-lg'))); ?>

            <?php endif; ?>
            <br><br>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ddms\resources\views/view/single.blade.php ENDPATH**/ ?>