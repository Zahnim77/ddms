

<?php $__env->startSection('title', '| All Jobs'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-10">
            <h1>Jobs</h1>
        </div>
        <div class="col-md-2">
            <a href="<?php echo e(route('jobs.create')); ?>" class="btn btn-primary btn-lg">Add New Job</a>
        </div>
        <div class="col-md-12">
            <hr>
        </div>
    </div><!-- Head row -->
    
    <div class="row"><!-- Jobs row -->
        <div class="col-md-12">
            <div class="text-center">
                <h3>Total Jobs: <?php echo e($jobs->total()); ?> </h3>
            </div>
            <table class="table table-hover"> 
                <thead class="thead-dark">
                    <tr>
                        <th>Job Title</th>
                        <th>Vacancy</th>
                        <th class="text-center">Job Details</th>
                        <th>Location</th>
                        <th>Posted</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                    <tr>
                        
                        <th><?php echo e($job->job_title); ?></th>
                        <td style="color:blue;"><?php echo e($job->vacancy); ?></td>

                        <td>
                            <?php echo e(substr($job->job_description, 0, 250)); ?>

                            <br>
                            <?php echo e(strlen($job->job_description) > 250 ? "....." : ""); ?>

                        </td>

                        <td><?php echo e($job->location); ?></td>
                        <td style="color:green;"><?php echo e(date('jS M\'Y', strtotime($job->created_at))); ?></td>
                        
                        <td>
                            <a href="<?php echo e(route( 'jobs.show', $job->id )); ?>" class="btn btn-secondary btn-sm">View</a>
                            <div><br></div>
                            <a href="<?php echo e(route( 'jobs.edit', $job->id )); ?>" class="btn btn-warning btn-sm">Edit</a>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo $jobs->links(); ?> <!-- pagination -->
            <div class="text-center">
                <?php echo $jobs->currentPage();; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ddms\resources\views/jobs/index.blade.php ENDPATH**/ ?>