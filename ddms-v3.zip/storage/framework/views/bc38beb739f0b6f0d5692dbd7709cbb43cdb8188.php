<?php $__env->startSection('title', "| $user->name Home"); ?>

<?php $__env->startSection('stylesheets'); ?>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if($user->jobs()->count() <= 0): ?>
        <div class="alert alert-warning" role="alert">
            You've not applied for a job yet.
        </div>
    <?php endif; ?>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-2 offset-md-10">
                    <a href="<?php echo e(route('view.index')); ?>" class="btn btn-dark">Apply for Jobs</a>
                </div>
            </div>
            
            <br>
            <div class="card">
                <div class="card-header">
                    <?php echo e($user->name); ?> Dashboard
                    <small>
                        (Applied to
                        <span class="w3-tag w3-round w3-yellow">
                            <span class="w3-badge w3-red"><?php echo e($user->jobs()->count()); ?></span> Jobs
                        </span>)
                    </small>
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table">
                                <thead class="thead-dark">
                                    <tr>
                                        <th class="text-center">Job Title</th>
                                        <th>Company</th>
                                        <th>Location</th>
                                        <th>Skills Needed</th>
                                        <th>Posted</th>
                                        <th>View</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $user->jobs()->orderBy('created_at', 'asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e($job->job_title); ?></th>
                                            <th style="color:darkmagenta"><?php echo e($job->company_name); ?></th>
                                            <td style="color:blue"><?php echo e($job->location); ?></td>
                                            <td>
                                                <?php $__currentLoopData = $job->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="w3-tag w3-round w3-teal">
                                                    <?php echo e($tag->name); ?>

                                                </span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>                                            
                                            <td>
                                                <?php echo e(date('jS M\'Y', strtotime($job->created_at))); ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('view.single', $job->slug)); ?>" class="btn btn-light btn-sm">
                                                    Job View
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ddms\resources\views/home.blade.php ENDPATH**/ ?>