<?php $__env->startSection('title', '| Jobs'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <h1>Jobs: <?php echo e($jobs->total()); ?></h1>
            <hr>
        </div>
    </div>

    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-md-8 offset-md-2">

            <h3><?php echo e($job->job_title); ?></h3>

            <h5>Vacancy: 
                <span style="color:blue;">
                    <?php echo e($job->vacancy); ?>

                </span>
                <span style="float:right; color:green;">
                    <?php echo e(date('jS M\'Y', strtotime($job->created_at))); ?>

                </span>
                <span style="float: right;">Published at:&nbsp;</span>
            </h5>

            <p>
                <?php echo e(substr($job->job_description, 0, 250)); ?>

                &nbsp;
                <?php echo e(strlen($job->job_description) > 250 ? "....." : ""); ?>

            </p>

            <a href="<?php echo e(route('view.single', $job->slug)); ?>" class="btn btn-link">.. Read more</a>
            <br>
            <br>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <div class="row">
        <div class="col-md-12">
            <?php echo $jobs->links(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ddms\resources\views/view/index.blade.php ENDPATH**/ ?>