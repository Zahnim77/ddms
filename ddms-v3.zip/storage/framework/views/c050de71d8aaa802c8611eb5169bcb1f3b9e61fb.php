<?php if(Session::has('success')): ?>
    <br>
    <div class="alert alert-success" role="alert">
        <strong>Success:</strong> <?php echo e(Session::get('success')); ?>

    </div>
<?php endif; ?>

<?php if(count($errors) > 0): ?>
    <br>
    <div class="alert alert-danger" role="alert">
        <strong>Errors: </strong>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(Session::has('delete')): ?>
    <br>
    <div class="alert alert-dark" role="alert">
        <strong>Deleted:</strong> <?php echo e(Session::get('delete')); ?>

    </div>
<?php endif; ?>

<?php if(Session::has('caution')): ?>
    <br>
    <div class="alert alert-warning" role="alert">
        <strong>Caution:</strong> <?php echo e(Session::get('caution')); ?>

    </div>
<?php endif; ?>

<?php if(Session::has('info')): ?>
    <br>
    <div class="alert alert-primary" role="alert">
        <strong>Check-out:</strong> <?php echo e(Session::get('info')); ?>

    </div>
<?php endif; ?><?php /**PATH E:\xampp\htdocs\ddms\resources\views/partials/messages.blade.php ENDPATH**/ ?>