

<?php $__env->startSection('title', "| $user->name Profile"); ?>

<?php $__env->startSection('stylesheets'); ?>
    <?php echo Html::style('css/parsley.css'); ?>  
    <?php echo Html::style('css/select2.min.css'); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">USER Profile</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-12">
                            <?php echo Form::model($user, ['route' => ['update.profile', $user->id], 'method' => 'PUT', 'files' => true, 'data-parsley-validate' => '' ]); ?>


                                <?php echo e(Form::label('name', 'Username:')); ?> 
                                <?php echo e(Form::text('name', null , array('class' => 'form-control', 'style'=>'font-size:1.5rem', 'required' => '', 'maxlength' => '255'))); ?>

                                <br>
                                <?php echo e(Form::label('avatar', 'Upload Photo:')); ?>

                                <br>
                                <?php if(isset($user->avatar)): ?>
                                <img src="<?php echo e(asset('/storage/avatars/'.$user->avatar)); ?>" alt="<?php echo e($user->avatar); ?>" />
                                <br>
                                <?php endif; ?>
                                <br>
                                <?php echo e(Form::file('avatar', array('class' => 'form-control'))); ?>

                                <br>
                                <?php echo e(Form::label('tags', "Choose Your Skills: ")); ?> <span style="color:blue;font-size:large;"><?php echo e($user->tags->count()); ?></span>
                                <?php echo e(Form::select('tags[]', $tags, null, ['class' => 'form-control select2-multiple', 'multiple' => 'multiple'])); ?>

                                <br><br>
                                <?php echo e(Form::label('cv', 'Upload Updated CV:')); ?>

                                <br>
                                <?php echo e(Form::file('cv', array('class' => 'form-control'))); ?>

                                <br>
                                <?php if(isset($user->cv)): ?>
                                <iframe src = "/js/ViewerJS/#<?php echo e(asset('/storage/cvs/'.$user->cv)); ?>" width='100%' height='360' allowfullscreen webkitallowfullscreen></iframe>
                                <br>
                                <?php endif; ?>
                                <br>
                                <div class="col-md-4 offset-md-4">
                                    <?php echo e(Form::submit('Update Profile', ['class' => 'btn btn-outline-primary btn-block'])); ?>

                                </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
            <br>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo Html::script('js/parsley.min.js'); ?>


    <?php echo Html::script('js/select2.min.js'); ?>

    <script type="text/javascript">
        $(document).ready(function() {
            $('.select2-multiple').select2();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ddms\resources\views/profile.blade.php ENDPATH**/ ?>