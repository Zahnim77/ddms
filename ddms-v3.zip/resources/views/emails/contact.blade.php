<div class="row">
    <div class="col-md-8 offset-md-2">
        <p>{{ $bodyMsg }}</p>
        <br>
        The email is sent from {{ $email }}
    </div>
</div>